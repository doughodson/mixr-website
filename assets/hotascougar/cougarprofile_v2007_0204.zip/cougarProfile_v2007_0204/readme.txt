
Compile cougarProfile using the supplied makefile.

Make sure to have libusb installed on your system.

Doug Hodson



