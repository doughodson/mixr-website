
//
// cougarProfile was written by Doug Hodson and Chris Buell
// March 2006
//
// This code is free, but if you use it for something else
// useful, please mentioned that it was found off the 
// OpenEaagles website.
//
// If you find bugs or make significant improvements,
// please let us know.
//


#include <iostream>
#include <fstream>
#include <usb.h>

enum Profile { DefaultProfile = 0, UserProfile = 1 };

bool
switchProfile(Profile profile, char* tmcBuf = 0, int tmcSize = 0)
{
  char buf[20];

  usb_init();
  usb_find_busses();
  usb_find_devices();

  struct usb_bus * busses = usb_get_busses();

  //
  // Loop through all busses
  //
  for( struct usb_bus * bus = busses; bus; bus = bus->next ) {
    struct usb_device *dev;
    int iep = 0;

    //
    // For each bus, loop through all devices
    //
    for( dev = bus->devices; dev; dev = dev->next ) {
      //
      // Look for Thrustmaster Inc and HOTAS HotasCougar
      //
      if( (dev->descriptor.idVendor == 0x044F) &&  (dev->descriptor.idProduct == 0x0400) ) {
        // Loop through all of the configurations
        for( int c = 0; c < dev->descriptor.bNumConfigurations; c++ ) {
          /* Loop through all of the interfaces */
          for( int i = 0; i < dev->config[c].bNumInterfaces; i++ ) {
            // Loop through all of the alternate settings
            for( int a = 0; a < dev->config[c].interface[i].num_altsetting; a++ ) {
              // Check if this endpoint is a bulk interface
              if( dev->config[c].interface[i].altsetting[a].endpoint[0].bmAttributes == USB_ENDPOINT_TYPE_BULK ) {
                if( (dev->config[c].interface[i].altsetting[a].endpoint[0].bEndpointAddress & USB_ENDPOINT_DIR_MASK) == 0 ) {
                  // This is an input endpoint
                  iep = dev->config[c].interface[i].altsetting[a].endpoint[0].bEndpointAddress;
                }
              }
            }
          }
        }
        struct usb_dev_handle * hand = usb_open( dev );
        if( hand == NULL ) {
          return false;
        }

        bool noErrors = true;

#if 1
        // CGB this is it
        if (profile == UserProfile && tmcSize > 0) {
          std::cout << ">>> Loading User Profile..." << std::endl;
          int n = usb_bulk_write( hand, iep, tmcBuf, tmcSize, 2000 );
          if (n < 0) {
            perror( "USB Command" );
            noErrors = false;
          }
        }
#endif

        std::cout << ">>> Setting Thrustmaster To User Profile..." << std::endl;
        buf[0] = 4;
        buf[1] = 1;
        int n = usb_bulk_write( hand, iep, buf, 2, 20 );
        if (n < 0) {
          perror( "USB Command" );
          noErrors = false;
        }

#if 1
        buf[0] = 7;
        n = usb_bulk_write( hand, iep, buf, 1, 20 );
        std::cout << ">>> Thrustmaster::Cougar: " << n << std::endl;
        if( n < 0 ) {
          perror( "USB");
          noErrors = false;
        }
#endif

        buf[0] = 3;
        buf[1] = profile;
        n = usb_bulk_write( hand, iep, buf, 2, 20 );
        if( n < 0 ) {
          perror( "USB Profile Switch" );
          noErrors = false;
        }

        n = usb_close( hand );
        if( n < 0 ) {
          perror( "Close USB" );
          noErrors = false;
        }

        return noErrors;
      }
    }
  }

  std::cout << ">>> No Thrustmaster Found" << std::endl;

  return false;
}


int
main(int argc, char* argv[])
{
  // usage:  cougarProfile      -- reset to Default Profile
  // usage:  cougarProfile profile.tmc  -- load a profile and set to User Profile
  if (argc != 2) {
    switchProfile(DefaultProfile);
  } else {
    char  tmcBuf[200];
    std::ifstream tmcFile(argv[1], std::ios::in | std::ios::binary);
    if (!tmcFile.fail() && !tmcFile.bad()) {
      tmcFile.read(tmcBuf, 200);
      int tmcSize = tmcFile.gcount();
      switchProfile(UserProfile, tmcBuf, tmcSize);
    }
  }
}

